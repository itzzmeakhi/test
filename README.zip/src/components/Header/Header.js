import React, { useState, useRef } from 'react';
import {
    Navbar,
    NavbarBrand,
    Nav,
    NavItem,
    NavLink,
    NavbarToggler,
    Collapse
} from 'reactstrap';
import { Link } from 'react-router-dom';
import { PublicClientApplication } from '@azure/msal-browser';

import { config } from './../../config';
import { getAccessToken } from './../../utils/graph-utils';

const Header = () => {
    const [toggleOpen, setToggleOpen] = useState(false);
    const [constructorHasRun, setConstructorHasRun] = useState(false);
    let publicClientApplication = useRef(null);
    const constructor = () => {
        if(constructorHasRun) return;
        publicClientApplication.current = new PublicClientApplication({
            auth: {
                clientId: config.clientId
            },
            cache: {
                cacheLocation: 'sessionStorage',
                storeAuthStateInCookie: true
            }
        })
        setConstructorHasRun(true);
    }
    constructor();
    const toggle = () => {
        setToggleOpen(prevState => {
            return !prevState;
        })
    }

    const login = async () => {
        try {
            await publicClientApplication.current.loginPopup({
                scopes: config.scopes,
                prompt: 'select_account'
            });
            const accessToken = await getAccessToken(publicClientApplication.current, config.scopes);
            localStorage.setItem('vz-access', accessToken);
        } catch(err) {
            console.log(err);
        }
    }
    return (
        <Navbar color="dark" dark expand="md">
            <NavbarBrand>Verizon Hiring</NavbarBrand>
            <NavbarToggler onClick={toggle} />
            <Collapse isOpen={toggleOpen} navbar>
                <Nav className="mr-auto" navbar>
                    <NavItem>
                        <NavLink tag={Link} to="/dashboard">Dashboard</NavLink>
                    </NavItem>
                    <NavItem>
                        <NavLink onClick={login}>Login</NavLink>
                    </NavItem>
                </Nav>
            </Collapse>
        </Navbar>
    )
}

export default Header;