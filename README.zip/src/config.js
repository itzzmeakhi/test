export const config = {
    clientId: '07edaf98-3053-470b-b01c-de6a10c184fb',
    scopes: [
        'user.read',
        'contacts.read',
        'files.readwrite.all'
    ]
}