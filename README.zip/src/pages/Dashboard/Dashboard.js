import React from 'react';
import StatisticsBoard from './../../components/StatisticsBoard/StatisticsBoard';

import axios from 'axios';

const Dashboard = () => {
    const formData = {
        grant_type: "client_credentials",
        client_id: "32087f03-0ba2-4824-8c7c-c57396035c87",
        client_secret: "vz-sheets-secret",
        scope: "https://graph.microsoft.com/.default"
    }
    console.log('Triggered');
    axios.post('https://login.microsoftonline.com/80a8b525-ef37-4cb0-9c21-75c25d9a0323/oauth2/v2.0/authorize', formData)
        .then(res => console.log(res))
 

    return(
        <div>
            <StatisticsBoard />
        </div>
    )
}

export default Dashboard;