import { getUserDetails } from './../GraphService';

export const getProfile = async(publicClientApplication, scopes) => {
    try {
        const accessToken = await getAccessToken(publicClientApplication, scopes);
        if(accessToken) {
            return await getUserDetails(accessToken)
        }
        return null;
    } catch(err) {
        console.log(err);
    }
}

export const getAccessToken = async(publicClientApplication, scopes) => {
    try {
        const accounts = publicClientApplication.getAllAccounts();
        if (accounts.length <= 0) throw new Error('login_required');
        const silentReq = await publicClientApplication.acquireTokenSilent({
            scopes: scopes,
            account: accounts[0]
        });
        return silentReq.accessToken;
    } catch(err) {
        console.log(err);
    }
}