export const config = {
    clientId: 'a47ee0ba-5eac-4bf0-81d3-0fddcaa95360',
    scopes: [
        'user.read.all',
        'contacts.read',
        'files.readwrite.all'
    ]
}