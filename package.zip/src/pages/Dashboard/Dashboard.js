import React, { useEffect } from 'react';
import StatisticsBoard from './../../components/StatisticsBoard/StatisticsBoard';

import axios from 'axios';

const Dashboard = () => {
    useEffect(() => {

    }, [])
    return(
        <div>
            <StatisticsBoard />
        </div>
    )
}

export default Dashboard;