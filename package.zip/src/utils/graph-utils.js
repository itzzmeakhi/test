import { PublicClientApplication } from '@azure/msal-browser';

const config = {
    clientId: 'a47ee0ba-5eac-4bf0-81d3-0fddcaa95360',
    scopes: [
        'user.read.all',
        'contacts.read',
        'files.readwrite.all'
    ]
}

const publicClientApplicationInstance = new PublicClientApplication({
    auth: {
        clientId: config.clientId
    },
    cache: {
        cacheLocation: 'localStorage',
        storeAuthStateInCookie: true
    }
});

const login = async () => {
    try {
        await publicClientApplicationInstance.loginPopup({
            scopes: config.scopes,
            prompt: 'select_account'
        });
        const accessToken = await getAccessToken(publicClientApplicationInstance, config.scopes);
        localStorage.setItem('vz-access-token', accessToken);
    } catch(err) {
        console.log(err);
    }
}

export default publicClientApplicationInstance;
export { login };